﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr16_zad3_Idrisov
{
    class Program
    {
        static void Main(string[] args)
        {
            
            List<double> numb = new List<double>();
            Console.WriteLine("Введите элементы массива");
            for (int i = 0; i < 10; i++)
            {
                numb.Add(double.Parse(Console.ReadLine()));
            }
            Console.WriteLine("Числа и их частота (число - частота):");
            var numbFre = numb
                .GroupBy(x => x)
                .Select(g => new { Number = g.Key, Count = g.Count() })
                .OrderBy(x => x.Number);
            foreach (var yach in numbFre)
            {
                Console.WriteLine($"{yach.Number} - {yach.Count}");
            }
            Console.WriteLine("\nЧисло * Частота (старого массива): ");
            var newArr = numb
                .GroupBy(x => x)
                .Select(g => new { Number = g.Key, Count = g.Count() })
                .OrderBy(x => x.Number);
            foreach (var yach in newArr)
            {
                Console.WriteLine($"{yach.Number} * {yach.Count} = {yach.Number * yach.Count}");
            }
            Console.ReadKey();
        }
    }
}
