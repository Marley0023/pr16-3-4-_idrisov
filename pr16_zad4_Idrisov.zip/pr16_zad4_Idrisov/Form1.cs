﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16_zad4_Idrisov
{
    public partial class Form1 : Form
    {
        private List<Country> countries;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (countries == null || countries.Count == 0)
            {
                MessageBox.Show("Сначала выгрузите информацию");
                return;
            }

            int populationLimit;
            if (int.TryParse(textBox1.Text, out populationLimit))
            {
                countries = countries.Where(c => c.Population > populationLimit).ToList();
                countries = countries.OrderBy(c => c.Name.Length).ThenBy(c => c.Name).ToList();
                listBox1.Items.Clear();
                foreach (Country country in countries)
                {
                    listBox1.Items.Add(country.Name + " " + country.Population);
                }
            }
            else
            {
                MessageBox.Show("Введите корректное число");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nameF = textBox2.Text;
            countries = new List<Country>();

            if (File.Exists(nameF))
            {
                string[] lines = File.ReadAllLines(nameF);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(' ');
                    string name = parts[0];
                    string chislStr = parts[1].Replace(" ", " ").Replace(" ", "");
                    int chisl;
                    if (int.TryParse(chislStr, out chisl))
                    {
                        countries.Add(new Country(name, chisl));
                    }
                    else
                    {
                        MessageBox.Show($"Численность населения: {chislStr}, для страны '{name}' не удалось преобразовать в число (возможно есть лишние пробелы)");
                    }
                }
                listBox1.Items.Clear();
                foreach (Country country in countries)
                {
                    listBox1.Items.Add(country.Name + " " + country.Population);
                }
            }
            else
            {
                MessageBox.Show("Не удалось найти файл");
            }

        }
    }



}
